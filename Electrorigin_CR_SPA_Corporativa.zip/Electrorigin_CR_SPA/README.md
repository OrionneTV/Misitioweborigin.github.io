# Electrorigin CR — SPA corporativa

Sitio de una sola página, responsive y sin backend, preparado para hospedarse como sitio estático.

## Contenido
- `index.html`: estructura y contenido.
- `styles.css`: identidad visual y diseño responsive.
- `script.js`: menú móvil, animaciones y formulario hacia WhatsApp.
- `assets/`: logo, ícono, retrato y vista previa para redes.
- `_headers` y `_redirects`: configuración compatible con Cloudflare Pages.
- `robots.txt` y `sitemap.xml`: archivos básicos para buscadores.

## Datos configurados
- Marca: Electrorigin CR
- Representante: Jonathan Zamora — Ejecutivo Comercial
- Teléfono / WhatsApp: 7242 9342
- Correo: Info@electrorigincr.com
- Dominio usado: https://electrorigincr.com

## Publicación en Cloudflare Pages
1. Cree un proyecto de Pages o use uno existente.
2. Suba el contenido completo de esta carpeta como sitio estático.
3. No se necesita comando de compilación.
4. La raíz del proyecto debe contener `index.html`.
5. Asocie `electrorigincr.com` desde **Custom domains**.

## Importante
- El formulario no almacena datos; abre WhatsApp con el mensaje preparado.
- Confirme que el dominio definitivo y el QR de las tarjetas coincidan.
- Los logos incluidos son rasterizados. Para rótulos o ampliaciones grandes se recomienda un vector maestro.
