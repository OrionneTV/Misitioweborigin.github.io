(() => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }));
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  const form = document.getElementById('whatsapp-form');
  const note = document.getElementById('form-note');
  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const interest = String(data.get('interest') || '').trim();
      const message = String(data.get('message') || '').trim();
      if (!name || !interest || !message) {
        note.textContent = 'Complete todos los campos para preparar el mensaje.';
        return;
      }
      const text = `Hola Electrorigin CR. Mi nombre es ${name}. Me interesa: ${interest}. ${message}`;
      const url = `https://wa.me/50672429342?text=${encodeURIComponent(text)}`;
      note.textContent = 'Abriendo WhatsApp…';
      window.open(url, '_blank', 'noopener');
    });
  }
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
